function example() {
    alert("hello!");
}